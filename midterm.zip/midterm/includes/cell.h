#include <iostream>
#include <string>
#include <vector>
using namespace std;

class genome{
    public:
    string _rna, RNA, _dna1, Rna, DNA1, DNA2, RNa, DNA11 , _s1, _s2, _s3, _s4, _s5, _s6;
    int _n1, _n2, s, c;
    char _ch1, _ch2, _ch3, _ch4;
    void setmokamelRNA(string rna);
    
    string getRNA();

    string MokamelRNA();

    void setjaheshKRNA(string rna ,char ch1 ,int n1 ,char ch2);

    string JaheshKRNA();

    void setJaheshKDNA1(string dna1, char ch3, int n2, char ch4);

    string JaheshKDNA1();

    string JaheshKDNA2();

    void SetJaheshBRNA(string rna, string s1, string s2);

    void SetjaheshBDNA(string dna1, string dna2, string s3, string s4);

    void reverseRNA(string rna, string s5);

    void setReversedna(string dna1, string s6);

    string reversedna();

    string reversedna2();
};
class cell : public genome{
    string _str1, _str2, _S1, _S2, cho1, cho2, mcho1, mcho2, chor3;
    int h, l, f, _N1, _N2, _N3, _N4, d;
    char _CH1, _CH2;
    public:
    void margselooli(string str1,string str2);

    string setinfo();

    void JaheshBDNA(int N1, int N2, vector<string> &v1, vector<string> &v2, string S1 , string S2);

    void setjaheshkk(vector<string> &v1, int N3, int N4, int CH1, int CH2);

    void setreversee(int N5, vector<string> &v1, string S3);

    void setpalindromee(vector<string> &v1 , int N6);

};