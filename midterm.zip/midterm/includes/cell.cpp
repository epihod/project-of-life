#include "cell.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;


    void genome :: setmokamelRNA(string rna){
        _rna = rna;
    }
    string genome ::  getRNA(){
        return _rna;
    }
    string genome :: MokamelRNA(){
            for(int q=0 ; q<_rna.length(); q++){
                if(_rna[q]>=65 && _rna[q]<=65){_rna[q]=_rna[q]+19;}
                else if(_rna[q]>=67 && _rna[q]<=67){_rna[q]=_rna[q]+4;}
                else if(_rna[q]>=84 && _rna[q]<=84){_rna[q]=_rna[q]-19;}
                else if(_rna[q]>=71 && _rna[q]<=71){_rna[q]=_rna[q]-4;}
            }
        return _rna;
    }
    void genome :: setjaheshKRNA(string rna ,char ch1 ,int n1 ,char ch2){
        RNA = rna , _ch1 = ch1 , _n1 = n1 , _ch2 = ch2 , s = 0;
    }
    string genome :: JaheshKRNA(){
        for(int i=0 ; i<RNA.length() ; i++){
                if(RNA[i]==_ch1 && s<_n1){
                    RNA[i]=_ch2;
                    s=s+1;
                }
                else{
                    RNA[i]=RNA[i];
                    s=s;
                }
        }
        return RNA;
    }
    void genome :: setJaheshKDNA1(string dna1, char ch3, int n2, char ch4){
        _dna1 = dna1 , _ch3 = ch3 , _n2 = n2 , _ch4 = ch4 , c=0;
    }
    string genome :: JaheshKDNA1(){
        for(int i=0 ; i<_dna1.length() ; i++){
                if(_dna1[i]==_ch3 && c<_n2){
                    _dna1[i]=_ch4;
                    c=c+1;
                }
                else{
                    _dna1[i]=_dna1[i];
                    c=c;
                }
        }
        return _dna1;
    }
    string genome :: JaheshKDNA2(){
        for(int q=0 ; q<_dna1.length(); q++){
                if(_dna1[q]>=65 && _dna1[q]<=65){_dna1[q]=_dna1[q]+19;}
                else if(_dna1[q]>=67 && _dna1[q]<=67){_dna1[q]=_dna1[q]+4;}
                else if(_dna1[q]>=84 && _dna1[q]<=84){_dna1[q]=_dna1[q]-19;}
                else if(_dna1[q]>=71 && _dna1[q]<=71){_dna1[q]=_dna1[q]-4;}
            }
            return _dna1;
    }
    void genome :: SetJaheshBRNA(string rna, string s1, string s2){
        Rna = rna , _s1 = s1 , _s2 = s2 ;
        size_t found = Rna.find(_s1);
        if(found != string :: npos ){
            for(int i = 0 ; i < found ; i++){
                cout << Rna[i];
            }
            cout<<_s2;
            for(int i = found+_s1.length() ; i < Rna.length() ; i++){
                cout << Rna[i];
            }
        }
        else{
            cout << "s1 not found.";
        }
    }
    void genome :: SetjaheshBDNA(string dna1, string dna2, string s3, string s4){
        DNA1 = dna1, DNA2 = dna2 , _s3 = s3 , _s4 = s4;
        size_t found1 = DNA1.find(_s3);
        if(found1 != string :: npos ){
            for(int i=0 ; i<found1 ; i++){
                cout << DNA1[i];
            }
            cout << _s4;
            for(int i = found1+_s3.length() ; i < DNA1.length() ; i++){
                cout << DNA1[i];
            }
            cout << endl;
            for(int i = 0 ; i  < found1 ; i++){
                cout << DNA2[i];
            }
            for(int q=0 ; q<_s4.length(); q++){
                if(_s4[q]>=65 && _s4[q]<=65){_s4[q]=_s4[q]+19;}
                else if(_s4[q]>=67 && _s4[q]<=67){_s4[q]=_s4[q]+4;}
                else if(_s4[q]>=84 && _s4[q]<=84){_s4[q]=_s4[q]-19;}
                else if(_s4[q]>=71 && _s4[q]<=71){_s4[q]=_s4[q]-4;}
                cout << _s4[q];
            }
            for(int i = found1+_s3.length() ; i< DNA1.length() ; i++){
                cout << DNA2[i];
            }
        }
        else{
            cout << "s1 not found.";
        }
    }
    void genome :: reverseRNA(string rna, string s5){
        RNa = rna , _s5 = s5 ;
        size_t found2 = RNa.find(_s5);
        if(found2 != string :: npos ){
            for(int i=0 ; i<_s5.length()/2 ; i++){
                swap(_s5[i] , _s5[_s5.length()-i-1]);
            }
            for(int i = 0 ; i < found2 ; i++){
                cout<<RNa[i];
            }
            cout << _s5;
            for(int i = found2+_s5.length() ; i < RNa.length() ; i++){
            cout << RNa[i];
            }  
        }
        else{
            cout << "s1 not found.";
        }
    }
    void genome :: setReversedna(string dna1, string s6){
        DNA11 = dna1 , _s6 = s6 ; 
    }
    string genome :: reversedna(){
        size_t found3 = DNA11.find(_s6);
        if(found3 != string :: npos ){
            for(int i=0 ; i<_s6.length()/2 ; i++){
                swap(_s6[i] , _s6[_s6.length() -i -1]);
            }
            for(int i=found3 ; i<found3 +_s6.length() ; i++){

                DNA11[i] = _s6[i-found3];
            }
            return DNA11;
        }
        else{
            return "s1 not found.";
        }
    }
    string genome :: reversedna2(){
        for(int q=0 ; q<DNA11.length() ; q++){
            if(DNA11[q]>=65 && DNA11[q]<=65){DNA11[q]=DNA11[q]+19;}
            else if(DNA11[q]>=67 && DNA11[q]<=67){DNA11[q]=DNA11[q]+4;}
            else if(DNA11[q]>=84 && DNA11[q]<=84){DNA11[q]=DNA11[q]-19;}
            else if(DNA11[q]>=71 && DNA11[q]<=71){DNA11[q]=DNA11[q]-4;}
        }
        return DNA11;
    }

    void cell :: margselooli(string str1,string str2){
        _str1 = str1 , _str2 = str2 , h=0 , l=0 , f=0;
        for(int i=0 ; i<_str1.length() ; i++){
            if(_str1[i]=='A' && _str2[i]=='T'){h=h;}
            else if(_str1[i]=='T' && _str2[i]=='A'){h=h;}
            else if(_str1[i]=='C' && _str2[i]=='G'){h=h;}
            else if(_str1[i]=='G' && _str2[i]=='C'){h=h;}
            else{h=h+1;}
        }
        for(int i=0 ; i<_str1.length() ; i++){
            if(_str1[i]=='A'){l=l+1;}
            else if(_str1[i]=='C'){f=f+1;}
            else{
                l=l;
                f=f;
            }
        }
        if(h>=5){cout<<"chromosome invalid.";}
        else if(l>(3*f)){cout<<"chromosome invalid.";}
        else{cout<<"chromosome accepted.";}
    }
    string cell :: setinfo(){
        if(h>=5){return "chromosome invalid.";}
        else if(l>(3*f)){return "chromosome invalid.";}
        else{return "chromosome accepted.";}
    }
    void cell :: JaheshBDNA(int N1, int N2, vector<string> &v1, vector<string> &v2, string S1 , string S2){
        _N1 = N1 , _N2 = N2 , cho1 = v1[N1-1] , cho2 = v1[N2-1], _S1 = S1 , _S2 = S2 , mcho1 = v2[N1-1] , mcho2 = v2[N2-1];
        size_t found4 = cho1.find(_S1);
        size_t found5 = cho2.find(_S2);
        if(found4 != string::npos && found5 != string::npos){
            for(int i = 0 ; i < found4 ; i++){
                cout << cho1[i];
            }
            cout << _S2;
            for(int i = found4+_S1.length() ; i<  cho1.length() ; i++){
                cout << cho1[i];
            }
            cout << endl;
            for(int i = 0 ; i < found4 ; i++){
                cout << mcho1[i];
            }
            for(int i = found5 ; i < found5+_S2.length() ; i++){
                cout << mcho2[i];
            }
            for(int i = found4+_S1.length(); i < cho1.length() ; i++){
                cout << mcho1[i];
            }
            cout << endl;
            for(int i = 0 ; i < found5 ; i++){
                cout << cho2[i];
            }
            cout << _S1;
            for(int i = found5+_S2.length() ; i < cho2.length() ; i++){
                cout << cho2[i];
            }
            cout << endl;
            for(int i = 0 ; i < found5 ; i++){
                cout << mcho2[i];
            }
            for(int i = found4 ; i < found4+_S1.length() ; i++){
                cout << mcho1[i];
            }
            for(int i = found5+_S2.length() ; i < cho2.length() ; i++){
                cout << mcho2[i];
            }
        }
    }
    void cell :: setjaheshkk(vector<string> &v1, int N3, int N4, int CH1, int CH2){
        _dna1 = v1[N3-1] , _ch3 = CH1 , _n2 = N4 , _ch4 = CH2 , c = 0 ;
    }
    void cell :: setreversee(int N5, vector<string> &v1, string S3){
        DNA11 = v1[N5-1] , _s6 = S3 ;
    }
    void cell :: setpalindromee(vector<string> &v1 , int N6){
        chor3 = v1[N6-1];
        int x=0;
        for(int i=0 ; i< chor3.length() ; i++){
            for(int j=4 ; j<= chor3.length() ; j=j+2){
                string strr;
                strr = chor3.substr(i , j);
                for (int a=0 ; a<strr.length()/2 ; a++){
                    if(strr[a] == 'A' && strr[strr.length()-a-1]=='T'){x=x+1;}
                    else if(strr[a] == 'T' && strr[strr.length()-a-1]=='A'){x=x+1;}
                    else if(strr[a] == 'C' && strr[strr.length()-a-1]=='G'){x=x+1;}
                    else if(strr[a] == 'G' && strr[strr.length()-a-1]=='C'){x=x+1;}
                    else{x=x;}
                }
                if(x==strr.length()/2 && strr.length()>=4){
                    cout << strr << endl;
                }
                x=0;
            }
        }
    }