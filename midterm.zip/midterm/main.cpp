#include <iostream>
#include <string>
#include <vector>
#include "includes/cell.h"
using namespace std;

int main(){
    cout << "Enter your choice:  " << endl << "1.cell/genome. " << endl << "2.cell/cell. " << endl ;
    int choice;
    cin >> choice;
    switch(choice){
        case 1:{
            class1: {
            cout << "genome class" << endl;
            }
            genome g;
            cout << "enter RNA: ";
            string rna;
            cin >> rna;
            string dna1 , dna2;
            cout << "first strand of DNA: ";
            cin >> dna1;
            cout << "second strand of DNA: ";
            cin >> dna2;
            g.setmokamelRNA(rna);
            cout << "the DNA that is made from the strand of RNA: " << endl << g.getRNA() << endl << g.MokamelRNA();
            operations:{
            cout << endl <<"choose your desired operation: 1.subtle mutation 2.big mutation 3.reverse mutation 4.class cell 5.end the program:  ";
            }
            int choice2;
            cin >> choice2;
            if (choice2 == 1){goto subtle_mut;}
            else if (choice2 == 2){goto big_mut;}
            else if (choice2 == 3){goto reverse_mut;}
            else if (choice2 == 4){goto classs;}
            else if( choice2 == 5){return 0;}
            else {cout << "try again!" << endl ; goto operations;}
            subtle_mut:{
                cout << endl << "for subtle mutation please enter ch1, n and ch2. " << endl << "RNA: ";
                int n1;
                char ch1, ch2;
                cin >> ch1 >> n1 >> ch2;
                g.setjaheshKRNA(rna, ch1, n1, ch2);
                cout << g.JaheshKRNA() << endl << "DNA: ";
                int n2;
                char ch3, ch4;
                cin >> ch3 >> n2 >> ch4;
                g.setJaheshKDNA1(dna1, ch3, n2, ch4);
                cout << g.JaheshKDNA1() << endl << g.JaheshKDNA2();
                goto operations;
            }
            big_mut:{
                cout << endl << "for big mutation please enter s1 and s2. " << endl << "RNA: ";
                string s1, s2;
                cin >> s1 >> s2;
                g.SetJaheshBRNA(rna, s1, s2);
                cout << endl << "DNA: ";
                string s3, s4;
                cin >> s3 >> s4;
                g.SetjaheshBDNA(dna1 , dna2, s3, s4);
                goto operations;
            }
            reverse_mut:{
                cout << endl << "for reverse mutation please enter s1. " << endl << "RNA: ";
                string s5;
                cin >> s5;
                g.reverseRNA(rna , s5);
                cout << endl << "DNA: ";
                string s6;
                cin >> s6;
                g.setReversedna(dna1, s6);
                cout << g.reversedna() << endl << g.reversedna2() ;
                goto operations;
                }
        }
    ///////////////////////////////////////////////////////////////////////////
        case 2:{
            classs:{
            cout << "cell class." << endl ;
            }
            cell c;
            vector<string> v1, v2;
            cout << endl << "enter the number of the Chromosomes: ";
            int N;
            cin >> N;
            string str1, str2, k;
            for(int i = 0 ; i < N ; i++){
            cout << i+1 << " :"<< "first strand of the chromosome: " << endl;
            cin >> str1;
            cout << "second strand of chromosome: " << endl;
            cin >> str2;
            c.margselooli(str1, str2);
            cout << endl;
            k = c.setinfo();
            if(k == "chromosome accepted."){
                v1.push_back(str1);
                v2.push_back(str2);
            }
            }
            cout << "all the accepted chromosomes: "<< endl;
            for(int i = 0 ; i < v1.size() ; i++){
                cout << i+1 << ":" << endl << v1[i] << endl <<v2[i] <<  endl;
            }
            opp: {
            cout << endl << "enter you desired operation: 1.big mutation 2. subtle mutation 3.reverse mutation 4.Complementary palindrome 5.class genome 6.end the program: ";
            }
            int choice3;
            cin >> choice3;
            if (choice3 == 1){goto bigg;}
            else if (choice3 == 2) {goto subb;}
            else if(choice3 == 3) {goto revv;}
            else if(choice3 == 4) {goto pal;}
            else if(choice3 == 5) {goto class1;}
            else if(choice3 == 6) {return 0;}
            else {cout << "try again!" << endl ; goto opp; }
            bigg:{
            cout << "for big mutation pleaSe enter s1, n, s2, m: ";
            string S1, S2;
            int N1, N2;
            cin >> S1 >> N1 >> S2 >> N2 ;
            c.JaheshBDNA(N1, N2, v1, v2, S1, S2);
            goto opp;
            }
            subb:{
            cout << endl << "enter m, n, ch1, ch2 for the subtle mutation: ";
            int N3, N4;
            char CH1, CH2;
            cin >> N3 >> N4 >> CH1 >> CH2;
            c.setjaheshkk(v1, N3, N4, CH1, CH2);
            cout << c.JaheshKDNA1() << endl << c.JaheshKDNA2() << endl ;
            goto opp;
            }
            revv:{
            cout << "enter n and s1 for the reverse mutation: ";
            int N5;
            string S3;
            cin >> N5 >> S3;
            c.setreversee(N5, v1, S3);
            cout << c.reversedna() << endl << c.reversedna2();
            goto opp;
            }
            pal:{
            cout << "enter the number of the chromosome to find every Complementary palindrome: ";
            int N6;
            cin >> N6;
            c.setpalindromee(v1 , N6);
            goto opp;
            }
        }
    }
    return 0;
}